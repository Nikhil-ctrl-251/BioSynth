import React, { useState } from 'react';
import { AlertTriangle, Info, ArrowRight, Sparkles, Loader2 } from 'lucide-react';
import { VariantItem } from '../types';

interface PredictedImpactPanelProps {
  variants: VariantItem[];
  onDeepAnalyze?: (variant: VariantItem) => void;
}

export const PredictedImpactPanel: React.FC<PredictedImpactPanelProps> = ({
  variants
}) => {
  const [analyzingId, setAnalyzingId] = useState<string | null>(null);
  const [aiPredictions, setAiPredictions] = useState<Record<string, { analysis: string; score: number; effect: string }>>({});

  const handleRunAiAnalysis = async (variant: VariantItem) => {
    setAnalyzingId(variant.id);
    try {
      const res = await fetch('/api/ai/predict-variant', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          variantType: variant.type,
          posStart: variant.posStart,
          refSeq: variant.refSeq,
          altSeq: variant.altSeq,
          codonChange: variant.codonChange,
          aminoAcidChange: variant.aminoAcidChange
        })
      });
      const data = await res.json();
      setAiPredictions((prev) => ({
        ...prev,
        [variant.id]: {
          analysis: data.analysis || "AI prediction completed.",
          score: data.pathogenicityScore || 0.85,
          effect: data.structuralEffect || "Secondary structure perturbation."
        }
      }));
    } catch (err) {
      console.error("AI Variant prediction failed:", err);
    } finally {
      setAnalyzingId(null);
    }
  };

  return (
    <div className="bg-[#1a2321] rounded-2xl p-6 glow-effect border border-[#1f6e65]/10 flex flex-col justify-between h-full">
      <div>
        <div className="flex justify-between items-center mb-4">
          <h3 className="font-serif-heading text-lg text-[#e0e6e4] font-semibold flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-[#8bd4c9]" />
            <span>Predicted Functional Impact</span>
          </h3>
          <span className="text-[11px] bg-[#1f6e65]/20 text-[#a3ede2] px-2 py-0.5 rounded border border-[#1f6e65]/30">
            AlphaFold &amp; Gemini
          </span>
        </div>

        <div className="space-y-3">
          {variants.slice(0, 2).map((v) => {
            const isMissense = v.type === 'Missense Mutation';
            const aiData = aiPredictions[v.id];

            return (
              <div
                key={v.id}
                className={`bg-[#171d1c] p-4 rounded-xl border-l-4 ${
                  isMissense ? 'border-[#ffb4ab]' : 'border-[#a6f0e5]'
                } flex items-start gap-3.5 hover:bg-[#1b2120] transition-colors`}
              >
                <div className="mt-0.5 shrink-0">
                  {isMissense ? (
                    <AlertTriangle className="w-5 h-5 text-[#ffb4ab]" />
                  ) : (
                    <Info className="w-5 h-5 text-[#a6f0e5]" />
                  )}
                </div>

                <div className="flex-1">
                  <div className="flex justify-between items-start">
                    <h4 className="font-medium text-sm text-[#dee4e2]">{v.title}</h4>
                    <span className="text-[11px] text-[#9baba8] font-mono-code">
                      Pos: {v.posStart === v.posEnd ? v.posStart : `${v.posStart}-${v.posEnd}`}
                    </span>
                  </div>

                  {isMissense ? (
                    <p className="text-xs text-[#bec9c6] mt-1 font-mono-code flex items-center gap-1">
                      <span className="text-[#ffb4ab] font-bold">{v.refSeq}</span>
                      <ArrowRight className="w-3 h-3 text-[#9baba8]" />
                      <span className="text-[#8bd4c9] font-bold">{v.altSeq}</span>
                      <span className="text-[#9baba8] ml-2">(Codon {v.codonChange})</span>
                    </p>
                  ) : (
                    <p className="text-xs text-[#bec9c6] mt-1 font-mono-code">
                      Insertion: <span className="text-[#a6f0e5] font-bold">{v.altSeq}</span>
                    </p>
                  )}

                  <div className="mt-2 text-xs bg-[#252b2a]/60 p-2 rounded text-[#9baba8] flex items-center justify-between">
                    <span>
                      {v.aminoAcidChange ? (
                        <>
                          Result: <strong className="text-[#dee4e2]">{v.aminoAcidChange}</strong>
                        </>
                      ) : (
                        v.description
                      )}
                    </span>
                    <button
                      onClick={() => handleRunAiAnalysis(v)}
                      disabled={analyzingId === v.id}
                      className="text-[10px] bg-[#1f6e65]/40 hover:bg-[#1f6e65] text-[#a3ede2] px-2 py-0.5 rounded transition-all flex items-center gap-1 shrink-0 ml-2"
                    >
                      {analyzingId === v.id ? (
                        <Loader2 className="w-3 h-3 animate-spin" />
                      ) : (
                        <Sparkles className="w-3 h-3" />
                      )}
                      <span>AI Insights</span>
                    </button>
                  </div>

                  {/* AI Prediction Callout */}
                  {aiData && (
                    <div className="mt-2 p-2.5 bg-[#1f6e65]/15 border border-[#1f6e65]/30 rounded-lg text-xs text-[#dee4e2]">
                      <div className="flex justify-between font-semibold text-[#8bd4c9] mb-1">
                        <span>Gemini Pathogenicity Score</span>
                        <span>{(aiData.score * 100).toFixed(0)}%</span>
                      </div>
                      <p className="text-[11px] leading-relaxed text-[#bec9c6]">{aiData.analysis}</p>
                    </div>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
