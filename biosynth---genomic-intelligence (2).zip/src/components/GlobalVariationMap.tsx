import React from 'react';
import { Map } from 'lucide-react';

interface GlobalVariationMapProps {
  viewPosition: number; // e.g. 2540
  onPositionSelect: (pos: number) => void;
  totalLength?: number;
}

export const GlobalVariationMap: React.FC<GlobalVariationMapProps> = ({
  viewPosition,
  onPositionSelect,
  totalLength = 12510
}) => {
  // Calculate relative left percentage for viewport window
  const pct = Math.min(Math.max((viewPosition / totalLength) * 100, 0), 90);

  const handleTrackClick = (e: React.MouseEvent<HTMLDivElement>) => {
    const rect = e.currentTarget.getBoundingClientRect();
    const clickX = e.clientX - rect.left;
    const ratio = clickX / rect.width;
    const newPos = Math.round(ratio * totalLength);
    onPositionSelect(newPos);
  };

  return (
    <div className="bg-[#1a2321] rounded-2xl p-6 glow-effect border border-[#1f6e65]/10">
      <div className="flex justify-between items-center mb-4">
        <h3 className="font-serif-heading text-lg text-[#e0e6e4] font-semibold flex items-center gap-2">
          <Map className="w-5 h-5 text-[#8bd4c9]" />
          <span>Global Variation Map</span>
        </h3>
        <div className="flex items-center gap-3 text-xs text-[#9baba8] font-mono-code">
          <span>0 kb</span>
          <div className="w-32 h-px bg-[#3f4947]/40"></div>
          <span>{(totalLength / 1000).toFixed(1)} kb</span>
        </div>
      </div>

      <div
        onClick={handleTrackClick}
        className="relative w-full h-16 bg-[#171d1c] rounded-lg border border-[#3f4947]/30 overflow-hidden cursor-crosshair group select-none"
        title="Click on map to jump sequence position"
      >
        {/* Base Track */}
        <div className="absolute inset-x-0 top-1/2 h-1 bg-[#303635] -translate-y-1/2"></div>

        {/* Density Histogram Bars */}
        <div className="absolute bottom-0 left-0 w-full h-8 flex items-end opacity-25 pointer-events-none">
          <div className="w-[5%] h-2 bg-[#8bd4c9] ml-[10%]"></div>
          <div className="w-[2%] h-6 bg-[#ffb4ab] ml-[15%]"></div>
          <div className="w-[8%] h-3 bg-[#8bd4c9] ml-[20%]"></div>
          <div className="w-[1%] h-8 bg-[#ffb4ab] ml-[5%]"></div>
          <div className="w-[15%] h-1 bg-[#8bd4c9] ml-[25%]"></div>
          <div className="w-[4%] h-5 bg-[#ffb4ab] ml-[10%]"></div>
        </div>

        {/* Highlighted Viewport Window */}
        <div
          style={{ left: `${pct}%` }}
          className="absolute top-0 bottom-0 w-[10%] bg-[#8bd4c9]/15 border-x border-[#8bd4c9]/60 z-10 backdrop-blur-[1px] transition-all duration-200 shadow-[0_0_15px_rgba(139,212,201,0.2)]"
        >
          <div className="absolute top-1 left-1/2 -translate-x-1/2 text-[9px] font-mono-code text-[#a3ede2] bg-[#1f6e65]/80 px-1 rounded">
            {viewPosition}bp
          </div>
        </div>

        {/* Mutation Markers */}
        <div className="absolute top-2 bottom-2 left-[20%] w-[2px] bg-[#ffb4ab] z-20" title="SNP Cluster"></div>
        <div className="absolute top-2 bottom-2 left-[25%] w-[2px] bg-[#a6f0e5] z-20" title="Insertion +GA"></div>
        <div className="absolute top-2 bottom-2 left-[60%] w-[2px] bg-[#ffb4ab] z-20" title="SNP Sub"></div>
        <div className="absolute top-2 bottom-2 left-[85%] w-[2px] bg-[#343a39] border border-[#889390] z-20" title="Deletion"></div>
      </div>
    </div>
  );
};
