import { AlignmentMetrics, EvidenceMetadata, Experiment, SequenceData, VariantItem } from '../types';

export const INITIAL_EXPERIMENT: Experiment = {
  id: 'exp-001',
  name: 'Alpha-Fold Variant',
  project: 'Alpha-Fold Variant',
  referenceName: 'HS_reference.fasta',
  sampleName: 'HS_sample_01.fasta',
  referenceBp: 12510,
  sampleBp: 12450,
  lastSynced: '2m ago',
  qualityScore: 98
};

export const INITIAL_METRICS: AlignmentMetrics = {
  identity: 97.82,
  coverage: 96.40,
  substitutions: 20,
  insertions: 4,
  deletions: 3,
  gapOpen: -10,
  gapExtend: -0.5,
  algorithm: 'Needleman-Wunsch (Global)'
};

export const INITIAL_METADATA: EvidenceMetadata = {
  alignmentMethod: 'Needleman-Wunsch (Global)',
  gapPenalty: 'Gap Open: -10, Ext: -0.5',
  referenceGenome: 'GRCh38.p13',
  annotationSource: 'Ensembl Release 109',
  analysisDate: '2024-05-20 14:32 UTC',
  qualityScore: 98
};

export const INITIAL_VARIANTS: VariantItem[] = [
  {
    id: 'var-1',
    title: 'Missense Mutation',
    type: 'Missense Mutation',
    posStart: 2553,
    posEnd: 2553,
    refSeq: 'C',
    altSeq: 'T',
    codonChange: 'GGA -> GAA',
    aminoAcidChange: 'Gly -> Glu',
    severity: 'high',
    description: 'Transition substitution disrupting hydrophobic core binding pocket in domain II.',
    siftScore: 0.02,
    polyphenScore: 0.89
  },
  {
    id: 'var-2',
    title: 'Frameshift Insertion',
    type: 'Frameshift Insertion',
    posStart: 2566,
    posEnd: 2567,
    refSeq: '--',
    altSeq: '+GA',
    codonChange: 'Frame Shift +2',
    aminoAcidChange: 'Frameshift downstream',
    severity: 'high',
    description: 'Potential disruption of downstream reading frame and premature stop codon induction.',
    siftScore: 0.00,
    polyphenScore: 0.98
  },
  {
    id: 'var-3',
    title: 'Synonymous Substitution',
    type: 'Synonymous',
    posStart: 2580,
    posEnd: 2580,
    refSeq: 'A',
    altSeq: 'G',
    codonChange: 'CTA -> CTG',
    aminoAcidChange: 'Leu -> Leu',
    severity: 'low',
    description: 'Silent substitution preserving primary amino acid sequence.',
    siftScore: 0.85,
    polyphenScore: 0.12
  },
  {
    id: 'var-4',
    title: 'Conservative Missense',
    type: 'Missense Mutation',
    posStart: 2612,
    posEnd: 2612,
    refSeq: 'G',
    altSeq: 'A',
    codonChange: 'GTC -> ATC',
    aminoAcidChange: 'Val -> Ile',
    severity: 'moderate',
    description: 'Conservative aliphatic substitution with minimal structural disturbance.',
    siftScore: 0.45,
    polyphenScore: 0.28
  }
];

// Helper to generate a baseline nucleotide sequence around position 2500-2700
function generateBaseSequence(): { ref: string; sample: string } {
  // Region around 2500 - 2700
  const prefix = "ATCGGCTAGCTAGCTAGCTAGCTAGCTAGCTAGCTAGCTAGCTAGCTAGCTAGCTAGCTAGCTAGCTAG";
  
  // 2540 to 2600 snippet matching screenshot exactly:
  // Ref:  ATCGGCTAGCTAG C TAGCTAGCTAGC -- TAGCTAGCTAGC A CG ...
  // Sam:  ATCGGCTAGCTAG T TAGCTAGCTAGC GA TAGCTAGCTAGC G CG ...
  
  const refMiddle = "ATCGGCTAGCTAGCTAGCTAGCTAGCTAGCTAGCTAGCTAGCTAGCACGATCGGCTAGCTAGCTAGCTAGCTAGCTAGCTAG";
  const samMiddle = "ATCGGCTAGCTAGTTAGCTAGCTAGCGATAGCTAGCTAGCGCGATCGGCTAGCTAGCTAGCTAGCTAGCTAGCTAG";

  const suffix = "GCTAGCTAGCTAGCTAGCTAGCTAGCTAGCTAGCTAGCTAGCTAGCTAGCTAGCTAGCTAGCTAGCTAG";

  return {
    ref: (prefix + refMiddle + suffix).repeat(50).slice(0, 12510),
    sample: (prefix + samMiddle + suffix).repeat(50).slice(0, 12450)
  };
}

const generated = generateBaseSequence();

export const INITIAL_SEQUENCE_DATA: SequenceData = {
  referenceName: 'HS_reference.fasta',
  referenceBp: 12510,
  referenceSeq: generated.ref,
  sampleName: 'HS_sample_01.fasta',
  sampleBp: 12450,
  sampleSeq: generated.sample
};

export const SAMPLE_EXPERIMENTS: Experiment[] = [
  {
    id: 'exp-001',
    name: 'Alpha-Fold Variant',
    project: 'Alpha-Fold Variant',
    referenceName: 'HS_reference.fasta',
    sampleName: 'HS_sample_01.fasta',
    referenceBp: 12510,
    sampleBp: 12450,
    lastSynced: '2m ago',
    qualityScore: 98
  },
  {
    id: 'exp-002',
    name: 'BRCA1 Exon 11 Mutation Map',
    project: 'Oncology Targets',
    referenceName: 'BRCA1_ref_GRCh38.fasta',
    sampleName: 'Patient_704_Exon11.fasta',
    referenceBp: 8420,
    sampleBp: 8415,
    lastSynced: '15m ago',
    qualityScore: 99
  },
  {
    id: 'exp-003',
    name: 'SARS-CoV-2 Spike Protein Variant',
    project: 'Virology Dynamics',
    referenceName: 'Wuhan_Hu_1.fasta',
    sampleName: 'BA_5_Subvariant.fasta',
    referenceBp: 29903,
    sampleBp: 29890,
    lastSynced: '1h ago',
    qualityScore: 96
  }
];
