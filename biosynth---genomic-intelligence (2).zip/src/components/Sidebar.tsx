import React from 'react';
import { Plus, BarChart2, GitBranch, FlaskConical, Wrench, BookOpen, HelpCircle, Dna } from 'lucide-react';
import { TabType } from '../types';

interface SidebarProps {
  activeTab: TabType;
  setActiveTab: (tab: TabType) => void;
  onNewExperiment: () => void;
  isMobileOpen?: boolean;
  setIsMobileOpen?: (open: boolean) => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  activeTab,
  setActiveTab,
  onNewExperiment,
  isMobileOpen,
  setIsMobileOpen
}) => {
  const navItems: { id: TabType; label: string; icon: React.ReactNode }[] = [
    { id: 'analysis', label: 'Analysis', icon: <BarChart2 className="w-5 h-5" /> },
    { id: 'variation', label: 'Variation', icon: <GitBranch className="w-5 h-5" /> },
    { id: 'biology', label: 'Biology', icon: <FlaskConical className="w-5 h-5" /> },
    { id: 'tools', label: 'Tools', icon: <Wrench className="w-5 h-5" /> },
  ];

  const handleNavClick = (tab: TabType) => {
    setActiveTab(tab);
    if (setIsMobileOpen) setIsMobileOpen(false);
  };

  return (
    <>
      {/* Mobile Backdrop */}
      {isMobileOpen && (
        <div
          onClick={() => setIsMobileOpen?.(false)}
          className="fixed inset-0 bg-black/60 z-40 md:hidden backdrop-blur-sm"
        />
      )}

      {/* Sidebar Container */}
      <aside
        className={`fixed left-0 top-0 h-full w-[280px] bg-[#171d1c] border-r border-[#1f6e65]/10 flex flex-col z-50 p-6 transition-transform duration-300 ${
          isMobileOpen ? 'translate-x-0' : '-translate-x-full md:translate-x-0'
        }`}
      >
        {/* Brand Header */}
        <div className="flex items-center gap-4 mb-8">
          <div className="w-10 h-10 rounded-full bg-[#1f6e65] flex items-center justify-center text-[#a3ede2] shadow-[0_0_20px_rgba(31,110,101,0.4)]">
            <Dna className="w-6 h-6" />
          </div>
          <div>
            <h1 className="font-serif-heading text-xl text-[#8bd4c9] font-bold leading-tight">
              Biosynth
            </h1>
            <p className="text-[11px] text-[#9baba8] tracking-wider uppercase mt-0.5">
              Genomic Intelligence
            </p>
          </div>
        </div>

        {/* New Experiment CTA */}
        <button
          onClick={() => {
            onNewExperiment();
            if (setIsMobileOpen) setIsMobileOpen(false);
          }}
          className="w-full bg-[#1f6e65] text-[#a3ede2] font-medium text-sm rounded-xl py-3 px-4 flex items-center justify-center gap-2 mb-8 btn-primary-glow hover:bg-[#258277] transition-all duration-300"
        >
          <Plus className="w-4 h-4" />
          <span>New Experiment</span>
        </button>

        {/* Main Navigation */}
        <div className="flex flex-col gap-2 flex-grow">
          {navItems.map((item) => {
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => handleNavClick(item.id)}
                className={`flex items-center gap-4 p-3 rounded-xl text-sm font-medium transition-all duration-300 group ${
                  isActive
                    ? 'bg-[#1f6e65] text-[#a3ede2] shadow-[0_0_20px_rgba(31,110,101,0.25)]'
                    : 'text-[#bec9c6] hover:bg-[#303635] hover:text-[#dee4e2] hover:translate-x-1'
                }`}
              >
                <span className="transition-transform group-hover:scale-110">
                  {item.icon}
                </span>
                <span>{item.label}</span>
              </button>
            );
          })}
        </div>

        {/* Bottom Navigation */}
        <div className="flex flex-col gap-2 mt-auto border-t border-[#1f6e65]/10 pt-6">
          <a
            href="#docs"
            onClick={(e) => {
              e.preventDefault();
              alert("Biosynth Documentation v2.4: Real-time global Needleman-Wunsch algorithm with gap open -10, extend -0.5.");
            }}
            className="flex items-center gap-4 text-[#bec9c6] hover:text-[#dee4e2] p-3 hover:bg-[#303635] rounded-xl text-sm font-medium transition-all duration-300 group"
          >
            <BookOpen className="w-5 h-5 transition-transform group-hover:scale-110" />
            <span>Documentation</span>
          </a>
          <a
            href="#support"
            onClick={(e) => {
              e.preventDefault();
              alert("Support Channel: Bioengineer desk open 24/7. Contact support@biosynth.io");
            }}
            className="flex items-center gap-4 text-[#bec9c6] hover:text-[#dee4e2] p-3 hover:bg-[#303635] rounded-xl text-sm font-medium transition-all duration-300 group"
          >
            <HelpCircle className="w-5 h-5 transition-transform group-hover:scale-110" />
            <span>Support</span>
          </a>
        </div>
      </aside>
    </>
  );
};
