import React, { useState } from 'react';
import { X, Plus, FlaskConical, FileText, CheckCircle2 } from 'lucide-react';
import { Experiment } from '../types';

interface NewExperimentModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectExperiment: (exp: Experiment) => void;
  onCreateCustomExperiment: (exp: Experiment) => void;
  availableExperiments: Experiment[];
  currentExperimentId: string;
}

export const NewExperimentModal: React.FC<NewExperimentModalProps> = ({
  isOpen,
  onClose,
  onSelectExperiment,
  onCreateCustomExperiment,
  availableExperiments,
  currentExperimentId
}) => {
  const [activeTab, setActiveTab] = useState<'preset' | 'custom'>('preset');
  const [name, setName] = useState('');
  const [project, setProject] = useState('Alpha-Fold Variant');
  const [refName, setRefName] = useState('HS_reference.fasta');
  const [sampleName, setSampleName] = useState('HS_sample_02.fasta');
  const [refBp, setRefBp] = useState('12510');
  const [sampleBp, setSampleBp] = useState('12450');

  if (!isOpen) return null;

  const handleCustomSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;
    const newExp: Experiment = {
      id: `exp-${Date.now()}`,
      name: name.trim(),
      project: project.trim() || 'General Genomics',
      referenceName: refName || 'ref.fasta',
      sampleName: sampleName || 'sample.fasta',
      referenceBp: parseInt(refBp, 10) || 10000,
      sampleBp: parseInt(sampleBp, 10) || 10000,
      lastSynced: 'Just now',
      qualityScore: Math.floor(Math.random() * 5) + 95
    };
    onCreateCustomExperiment(newExp);
    onClose();
  };

  return (
    <div className="fixed inset-0 bg-black/70 backdrop-blur-md z-50 flex items-center justify-center p-4">
      <div className="bg-[#1a2321] border border-[#1f6e65]/30 rounded-2xl max-w-xl w-full p-6 shadow-2xl relative glow-effect">
        <button
          onClick={onClose}
          className="absolute top-5 right-5 text-[#bec9c6] hover:text-[#dee4e2] p-1.5 rounded-lg hover:bg-[#303635] transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="flex items-center gap-3 mb-6">
          <div className="w-10 h-10 rounded-full bg-[#1f6e65]/30 flex items-center justify-center text-[#8bd4c9]">
            <FlaskConical className="w-5 h-5" />
          </div>
          <div>
            <h3 className="font-serif-heading text-xl text-[#e0e6e4] font-bold">
              Select or Create Experiment
            </h3>
            <p className="text-xs text-[#9baba8]">
              Switch comparative datasets or initialize a custom sequencing pipeline
            </p>
          </div>
        </div>

        {/* Tab Headers */}
        <div className="flex border-b border-[#3f4947]/30 mb-5">
          <button
            onClick={() => setActiveTab('preset')}
            className={`pb-2.5 px-4 text-xs font-semibold border-b-2 transition-all ${
              activeTab === 'preset'
                ? 'border-[#8bd4c9] text-[#8bd4c9]'
                : 'border-transparent text-[#bec9c6] hover:text-[#dee4e2]'
            }`}
          >
            Preset Workbenches
          </button>
          <button
            onClick={() => setActiveTab('custom')}
            className={`pb-2.5 px-4 text-xs font-semibold border-b-2 transition-all ${
              activeTab === 'custom'
                ? 'border-[#8bd4c9] text-[#8bd4c9]'
                : 'border-transparent text-[#bec9c6] hover:text-[#dee4e2]'
            }`}
          >
            New Custom Experiment
          </button>
        </div>

        {activeTab === 'preset' ? (
          <div className="space-y-3 max-h-[340px] overflow-y-auto pr-1">
            {availableExperiments.map((exp) => {
              const isSelected = exp.id === currentExperimentId;
              return (
                <div
                  key={exp.id}
                  onClick={() => {
                    onSelectExperiment(exp);
                    onClose();
                  }}
                  className={`p-4 rounded-xl border cursor-pointer transition-all ${
                    isSelected
                      ? 'bg-[#1f6e65]/20 border-[#1f6e65] shadow-[0_0_15px_rgba(31,110,101,0.2)]'
                      : 'bg-[#171d1c] border-[#3f4947]/30 hover:border-[#1f6e65]/50 hover:bg-[#1b2120]'
                  }`}
                >
                  <div className="flex justify-between items-start">
                    <div className="flex items-center gap-2">
                      <h4 className="font-semibold text-sm text-[#dee4e2]">{exp.name}</h4>
                      {isSelected && (
                        <span className="flex items-center gap-1 text-[10px] bg-[#1f6e65] text-[#a3ede2] px-2 py-0.5 rounded-full font-medium">
                          <CheckCircle2 className="w-3 h-3" /> Active
                        </span>
                      )}
                    </div>
                    <span className="text-xs text-[#9baba8] font-mono-code">{exp.lastSynced}</span>
                  </div>

                  <p className="text-xs text-[#9baba8] mt-1">Project: {exp.project}</p>

                  <div className="flex items-center gap-4 mt-3 text-xs font-mono-code text-[#bec9c6]">
                    <span className="flex items-center gap-1">
                      <FileText className="w-3.5 h-3.5 text-[#8bd4c9]" />
                      Ref: {exp.referenceName} ({exp.referenceBp.toLocaleString()} bp)
                    </span>
                    <span className="flex items-center gap-1">
                      <FlaskConical className="w-3.5 h-3.5 text-[#8bd4c9]" />
                      Sample: {exp.sampleName} ({exp.sampleBp.toLocaleString()} bp)
                    </span>
                  </div>
                </div>
              );
            })}
          </div>
        ) : (
          <form onSubmit={handleCustomSubmit} className="space-y-4 text-xs">
            <div>
              <label className="block text-[#bec9c6] font-medium mb-1">Experiment Title</label>
              <input
                type="text"
                required
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="e.g., TP53 DNA Binding Domain Screen"
                className="w-full bg-[#171d1c] border border-[#3f4947]/40 rounded-xl px-3.5 py-2 text-[#dee4e2] focus:outline-none focus:border-[#8bd4c9]"
              />
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-[#bec9c6] font-medium mb-1">Project Category</label>
                <input
                  type="text"
                  value={project}
                  onChange={(e) => setProject(e.target.value)}
                  className="w-full bg-[#171d1c] border border-[#3f4947]/40 rounded-xl px-3.5 py-2 text-[#dee4e2] focus:outline-none focus:border-[#8bd4c9]"
                />
              </div>
              <div>
                <label className="block text-[#bec9c6] font-medium mb-1">Target Reference File</label>
                <input
                  type="text"
                  value={refName}
                  onChange={(e) => setRefName(e.target.value)}
                  className="w-full bg-[#171d1c] border border-[#3f4947]/40 rounded-xl px-3.5 py-2 text-[#dee4e2] focus:outline-none focus:border-[#8bd4c9]"
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-[#bec9c6] font-medium mb-1">Sample Query File</label>
                <input
                  type="text"
                  value={sampleName}
                  onChange={(e) => setSampleName(e.target.value)}
                  className="w-full bg-[#171d1c] border border-[#3f4947]/40 rounded-xl px-3.5 py-2 text-[#dee4e2] focus:outline-none focus:border-[#8bd4c9]"
                />
              </div>
              <div>
                <label className="block text-[#bec9c6] font-medium mb-1">Sequence Length (bp)</label>
                <input
                  type="number"
                  value={sampleBp}
                  onChange={(e) => setSampleBp(e.target.value)}
                  className="w-full bg-[#171d1c] border border-[#3f4947]/40 rounded-xl px-3.5 py-2 text-[#dee4e2] focus:outline-none focus:border-[#8bd4c9]"
                />
              </div>
            </div>

            <div className="pt-3 flex justify-end gap-3">
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2 rounded-xl text-[#bec9c6] hover:bg-[#303635]"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="bg-[#1f6e65] text-[#a3ede2] px-5 py-2 rounded-xl font-medium flex items-center gap-2 hover:bg-[#258277] btn-primary-glow"
              >
                <Plus className="w-4 h-4" />
                <span>Initialize Experiment</span>
              </button>
            </div>
          </form>
        )}
      </div>
    </div>
  );
};
