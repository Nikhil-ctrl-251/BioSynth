import React, { useState, useEffect } from 'react';
import { X, Sparkles, Download, CheckCircle2, FileText, Loader2, Share2 } from 'lucide-react';
import { AlignmentMetrics, Experiment, VariantItem } from '../types';

interface ExecutiveReportModalProps {
  isOpen: boolean;
  onClose: () => void;
  experiment: Experiment;
  metrics: AlignmentMetrics;
  variants: VariantItem[];
}

export const ExecutiveReportModal: React.FC<ExecutiveReportModalProps> = ({
  isOpen,
  onClose,
  experiment,
  metrics,
  variants
}) => {
  const [loading, setLoading] = useState<boolean>(true);
  const [report, setReport] = useState<{
    executiveSummary: string;
    keyFindings: string[];
    biologicalSignificance: string;
  } | null>(null);

  useEffect(() => {
    if (isOpen) {
      generateReport();
    }
  }, [isOpen]);

  const generateReport = async () => {
    setLoading(true);
    try {
      const res = await fetch('/api/ai/analyze-experiment', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          experimentName: experiment.name,
          referenceName: experiment.referenceName,
          sampleName: experiment.sampleName,
          identity: metrics.identity,
          coverage: metrics.coverage,
          substitutions: metrics.substitutions,
          insertions: metrics.insertions,
          deletions: metrics.deletions,
          variants
        })
      });
      const data = await res.json();
      setReport({
        executiveSummary: data.executiveSummary || 'Genomic analysis complete.',
        keyFindings: data.keyFindings || [
          'Sequence identity matches 97.82% of human reference baseline.',
          'Critical missense mutation at position 2553 alters codon GGA to GAA.',
          'Frameshift insertion detected between position 2566 and 2567.'
        ],
        biologicalSignificance: data.biologicalSignificance || 'High probability of altered protein binding kinetics in domain II.'
      });
    } catch (err) {
      console.error('Failed to generate report:', err);
    } finally {
      setLoading(false);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/75 backdrop-blur-md z-50 flex items-center justify-center p-4">
      <div className="bg-[#1a2321] border border-[#1f6e65]/40 rounded-2xl max-w-2xl w-full p-6 sm:p-8 shadow-2xl relative glow-effect max-h-[90vh] flex flex-col">
        <button
          onClick={onClose}
          className="absolute top-5 right-5 text-[#bec9c6] hover:text-[#dee4e2] p-1.5 rounded-lg hover:bg-[#303635] transition-colors"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="flex items-center gap-3 mb-6">
          <div className="w-11 h-11 rounded-full bg-[#1f6e65]/30 border border-[#1f6e65]/50 flex items-center justify-center text-[#8bd4c9]">
            <Sparkles className="w-6 h-6" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h3 className="font-serif-heading text-xl text-[#e0e6e4] font-bold">
                Executive Intelligence Report
              </h3>
              <span className="text-[10px] bg-[#1f6e65] text-[#a3ede2] px-2 py-0.5 rounded-full font-mono-code">
                Gemini 3.6
              </span>
            </div>
            <p className="text-xs text-[#9baba8] mt-0.5">
              Comparative Workbench Analysis for {experiment.name}
            </p>
          </div>
        </div>

        {loading ? (
          <div className="py-16 flex flex-col items-center justify-center gap-3 text-center">
            <Loader2 className="w-10 h-10 text-[#8bd4c9] animate-spin" />
            <p className="text-sm font-medium text-[#dee4e2]">
              Synthesizing Genomic Evidence &amp; Predictive Structural Effects...
            </p>
            <p className="text-xs text-[#9baba8]">
              Analyzing global alignment matrix, codon shifts, and SIFT scores
            </p>
          </div>
        ) : (
          <div className="space-y-6 overflow-y-auto pr-2 text-sm text-[#dee4e2]">
            {/* Overview Banner */}
            <div className="bg-[#171d1c] p-4 rounded-xl border border-[#3f4947]/30 grid grid-cols-3 gap-2 text-center">
              <div>
                <p className="text-[11px] text-[#9baba8] uppercase">Identity</p>
                <p className="text-lg font-serif-heading text-[#8bd4c9] font-bold">
                  {metrics.identity}%
                </p>
              </div>
              <div>
                <p className="text-[11px] text-[#9baba8] uppercase">Coverage</p>
                <p className="text-lg font-serif-heading text-[#dee4e2] font-bold">
                  {metrics.coverage}%
                </p>
              </div>
              <div>
                <p className="text-[11px] text-[#9baba8] uppercase">Variants</p>
                <p className="text-lg font-serif-heading text-[#ffb4ab] font-bold">
                  {variants.length}
                </p>
              </div>
            </div>

            {/* Executive Summary */}
            <div>
              <h4 className="text-xs uppercase tracking-wider font-semibold text-[#8bd4c9] mb-2 flex items-center gap-1.5">
                <FileText className="w-4 h-4" />
                Executive Summary
              </h4>
              <p className="bg-[#171d1c] p-4 rounded-xl border border-[#3f4947]/20 leading-relaxed text-xs sm:text-sm text-[#bec9c6]">
                {report?.executiveSummary}
              </p>
            </div>

            {/* Key Scientific Findings */}
            <div>
              <h4 className="text-xs uppercase tracking-wider font-semibold text-[#8bd4c9] mb-2 flex items-center gap-1.5">
                <CheckCircle2 className="w-4 h-4" />
                Key Findings
              </h4>
              <ul className="space-y-2">
                {report?.keyFindings.map((finding, idx) => (
                  <li key={idx} className="flex items-start gap-2.5 bg-[#171d1c] p-3 rounded-lg text-xs text-[#dee4e2] border border-[#3f4947]/20">
                    <span className="w-5 h-5 rounded-full bg-[#1f6e65]/30 text-[#8bd4c9] text-[10px] font-bold flex items-center justify-center shrink-0 mt-0.5">
                      {idx + 1}
                    </span>
                    <span className="leading-relaxed">{finding}</span>
                  </li>
                ))}
              </ul>
            </div>

            {/* Biological Significance */}
            <div>
              <h4 className="text-xs uppercase tracking-wider font-semibold text-[#8bd4c9] mb-2">
                Biological &amp; Structural Impact
              </h4>
              <p className="bg-[#1f6e65]/15 border border-[#1f6e65]/30 p-4 rounded-xl text-xs sm:text-sm text-[#a3ede2] leading-relaxed">
                {report?.biologicalSignificance}
              </p>
            </div>
          </div>
        )}

        <div className="mt-6 pt-4 border-t border-[#3f4947]/30 flex justify-between items-center text-xs">
          <span className="text-[#9baba8] font-mono-code">Generated by Biosynth AI v2.4</span>
          <div className="flex gap-2">
            <button
              onClick={() => alert('Report link copied to clipboard!')}
              className="px-3.5 py-2 rounded-xl bg-[#252b2a] text-[#dee4e2] hover:bg-[#303635] flex items-center gap-1.5 transition-colors"
            >
              <Share2 className="w-3.5 h-3.5" />
              <span>Share</span>
            </button>
            <button
              onClick={() => {
                alert('Downloading Executive Report PDF...');
                onClose();
              }}
              className="px-4 py-2 rounded-xl bg-[#1f6e65] text-[#a3ede2] hover:bg-[#258277] font-medium flex items-center gap-1.5 transition-colors btn-primary-glow"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Export PDF</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
