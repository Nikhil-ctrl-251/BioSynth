import React, { useState } from 'react';
import { ZoomIn, ZoomOut, Download, Search, Sparkles, Info } from 'lucide-react';
import { SequenceData } from '../types';

interface SequenceViewerProps {
  sequenceData: SequenceData;
  startPos: number;
  onSelectBase?: (pos: number) => void;
  onDeepAnalyzeVariant?: (pos: number, ref: string, alt: string) => void;
}

export const SequenceViewer: React.FC<SequenceViewerProps> = ({
  sequenceData,
  startPos,
  onDeepAnalyzeVariant
}) => {
  const [zoomLevel, setZoomLevel] = useState<number>(1); // 1 = normal, 2 = zoomed in, 0.5 = zoomed out
  const [selectedPos, setSelectedPos] = useState<number | null>(2553);
  const [jumpInput, setJumpInput] = useState<string>('');
  const [showJumpModal, setShowJumpModal] = useState<boolean>(false);

  // Calculate slice range based on startPos and zoomLevel
  const windowLength = Math.round(70 / zoomLevel);
  const effectiveStart = Math.max(0, startPos);
  
  // Create exact snippet representation around current view position
  // 2540 to 2600 reference & sample mapping
  const rulerTicks = [];
  const tickStep = 10;
  const startRuler = Math.floor(effectiveStart / tickStep) * tickStep;
  for (let pos = startRuler; pos <= startRuler + windowLength; pos += tickStep) {
    rulerTicks.push(pos);
  }

  const handleZoomIn = () => setZoomLevel((z) => Math.min(z + 0.5, 2.5));
  const handleZoomOut = () => setZoomLevel((z) => Math.max(z - 0.25, 0.5));

  const handleExportFasta = () => {
    const fastaContent = `>Reference_${sequenceData.referenceName}\n${sequenceData.referenceSeq}\n>Sample_${sequenceData.sampleName}\n${sequenceData.sampleSeq}`;
    const blob = new Blob([fastaContent], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `biosynth_alignment_${startPos}.fasta`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleJump = (e: React.FormEvent) => {
    e.preventDefault();
    const num = parseInt(jumpInput, 10);
    if (!isNaN(num)) {
      setSelectedPos(num);
      setShowJumpModal(false);
    }
  };

  return (
    <div className="bg-[#1a2321] rounded-2xl glow-effect border border-[#1f6e65]/10 overflow-hidden flex flex-col min-h-[420px]">
      {/* Header Controls */}
      <div className="p-4 border-b border-[#1f6e65]/10 bg-[#1b2120]/50 flex flex-wrap justify-between items-center gap-3 z-10">
        <div className="flex items-center gap-4">
          <h3 className="font-serif-heading text-lg text-[#e0e6e4] font-semibold">
            Sequence Viewer
          </h3>
          <div className="bg-[#252b2a] rounded-full flex items-center p-1 border border-[#3f4947]/20">
            <button
              onClick={handleZoomIn}
              className="w-7 h-7 rounded-full bg-[#1a2321] text-[#dee4e2] shadow-sm flex items-center justify-center text-xs hover:bg-[#343a39] transition-colors"
              title="Zoom In"
            >
              <ZoomIn className="w-4 h-4" />
            </button>
            <button
              onClick={handleZoomOut}
              className="w-7 h-7 rounded-full text-[#bec9c6] hover:text-[#dee4e2] flex items-center justify-center text-xs transition-colors"
              title="Zoom Out"
            >
              <ZoomOut className="w-4 h-4" />
            </button>
          </div>
          <button
            onClick={() => setShowJumpModal(!showJumpModal)}
            className="text-xs text-[#8bd4c9] hover:text-[#a6f0e5] flex items-center gap-1 bg-[#1f6e65]/20 px-2.5 py-1 rounded-full border border-[#1f6e65]/30"
          >
            <Search className="w-3.5 h-3.5" />
            <span>Pos: {effectiveStart}bp</span>
          </button>
        </div>

        <div className="flex items-center gap-2">
          {showJumpModal && (
            <form onSubmit={handleJump} className="flex items-center gap-2">
              <input
                type="number"
                placeholder="Jump to bp..."
                value={jumpInput}
                onChange={(e) => setJumpInput(e.target.value)}
                className="bg-[#0f1514] border border-[#1f6e65]/50 text-xs text-[#dee4e2] px-2.5 py-1 rounded-lg w-28 focus:outline-none"
              />
              <button
                type="submit"
                className="text-xs bg-[#1f6e65] text-[#a3ede2] px-2.5 py-1 rounded-lg font-medium"
              >
                Go
              </button>
            </form>
          )}

          <button
            onClick={handleExportFasta}
            className="text-xs bg-[#252b2a] hover:bg-[#343a39] text-[#dee4e2] border border-[#3f4947]/30 rounded-lg px-3 py-1.5 transition-colors flex items-center gap-1.5 font-mono-code"
          >
            <Download className="w-3.5 h-3.5 text-[#8bd4c9]" />
            <span>Export FASTA</span>
          </button>
        </div>
      </div>

      {/* Sequence Canvas */}
      <div className="flex-1 overflow-x-auto sequence-scroll bg-[#0a0e0d] p-6 relative font-mono-code text-sm leading-relaxed tracking-[0.25em] select-none">
        {/* Position Ruler */}
        <div className="flex mb-4 text-[#889390] sticky top-0 bg-[#0a0e0d]/90 backdrop-blur-sm z-10 text-[11px]">
          <div className="w-28 shrink-0 font-sans text-xs text-[#9baba8]">Position</div>
          <div className="flex-1 flex justify-between min-w-[760px] pr-8">
            {rulerTicks.map((pos) => (
              <span key={pos} className="hover:text-[#8bd4c9] cursor-pointer" onClick={() => setSelectedPos(pos)}>
                | {pos}
              </span>
            ))}
          </div>
        </div>

        {/* Reference Sequence Row */}
        <div className="flex items-center mb-3 min-w-[760px] hover:bg-[#090f0e] p-1.5 rounded transition-colors group">
          <div className="w-28 shrink-0 text-[#9baba8] text-xs font-sans font-medium">Reference</div>
          <div className="flex-1 text-[#dee4e2] flex items-center font-mono-code font-medium">
            <span>ATCGGCTAGCTAG</span>
            <span
              onClick={() => setSelectedPos(2553)}
              className="text-[#ffb4ab] bg-[#ffb4ab]/15 border-b-2 border-[#ffb4ab] relative group/tip cursor-pointer px-0.5 rounded-sm mx-0.5"
            >
              C
              <div className="absolute -top-9 left-1/2 -translate-x-1/2 bg-[#1a2321] border border-[#ffb4ab]/40 text-[#ffb4ab] text-[10px] px-2 py-1 rounded hidden group-hover/tip:block z-30 whitespace-nowrap shadow-xl">
                Wildtype: C (Pos 2553)
              </div>
            </span>
            <span>TAGCTAGCTAGC</span>
            <span className="text-[#303635] px-0.5">-</span>
            <span className="text-[#303635] px-0.5">-</span>
            <span>TAGCTAGCTAGC</span>
            <span
              onClick={() => setSelectedPos(2580)}
              className="text-[#ffb4ab] bg-[#ffb4ab]/15 border-b-2 border-[#ffb4ab] relative group/tip cursor-pointer px-0.5 rounded-sm mx-0.5"
            >
              A
              <div className="absolute -top-9 left-1/2 -translate-x-1/2 bg-[#1a2321] border border-[#ffb4ab]/40 text-[#ffb4ab] text-[10px] px-2 py-1 rounded hidden group-hover/tip:block z-30 whitespace-nowrap shadow-xl">
                Wildtype: A (Pos 2580)
              </div>
            </span>
            <span>CGATCGGCTAGCTAG</span>
          </div>
        </div>

        {/* Match Indicator Row (Stars / Spaces) */}
        <div className="flex items-center mb-3 min-w-[760px] opacity-35">
          <div className="w-28 shrink-0"></div>
          <div className="flex-1 text-[#8bd4c9] font-mono-code text-xs tracking-[0.25em]">
            <span>*************</span>
            <span className="text-transparent"> </span>
            <span>************</span>
            <span className="text-transparent">  </span>
            <span>************</span>
            <span className="text-transparent"> </span>
            <span>***************</span>
          </div>
        </div>

        {/* Sample Sequence Row */}
        <div className="flex items-center min-w-[760px] hover:bg-[#090f0e] p-1.5 rounded transition-colors group">
          <div className="w-28 shrink-0 text-[#8bd4c9] text-xs font-sans font-semibold flex items-center gap-1">
            <span>Sample_01</span>
          </div>
          <div className="flex-1 text-[#dee4e2] flex items-center font-mono-code font-medium">
            <span>ATCGGCTAGCTAG</span>
            <span
              onClick={() => setSelectedPos(2553)}
              className="text-[#8bd4c9] bg-[#1f6e65]/40 border-b-2 border-[#8bd4c9] font-bold relative group/tip cursor-pointer px-0.5 rounded-sm mx-0.5 shadow-[0_0_8px_rgba(31,110,101,0.6)]"
            >
              T
              <div className="absolute bottom-7 left-1/2 -translate-x-1/2 bg-[#1a2321] border border-[#8bd4c9]/50 text-[#8bd4c9] text-[10px] px-2 py-1 rounded hidden group-hover/tip:block z-30 shadow-[0_0_15px_rgba(31,110,101,0.5)] whitespace-nowrap">
                Mutated to T (Missense: Gly-&gt;Glu)
              </div>
            </span>
            <span>TAGCTAGCTAGC</span>
            <span
              onClick={() => setSelectedPos(2566)}
              className="text-[#a6f0e5] bg-[#a6f0e5]/25 border-b-2 border-[#a6f0e5] font-bold cursor-pointer px-0.5 rounded-sm"
              title="Insertion: G"
            >
              G
            </span>
            <span
              onClick={() => setSelectedPos(2567)}
              className="text-[#a6f0e5] bg-[#a6f0e5]/25 border-b-2 border-[#a6f0e5] font-bold cursor-pointer px-0.5 rounded-sm"
              title="Insertion: A"
            >
              A
            </span>
            <span>TAGCTAGCTAGC</span>
            <span
              onClick={() => setSelectedPos(2580)}
              className="text-[#8bd4c9] bg-[#1f6e65]/40 border-b-2 border-[#8bd4c9] font-bold cursor-pointer px-0.5 rounded-sm mx-0.5"
              title="Substitution: G"
            >
              G
            </span>
            <span>CGATCGGCTAGCTAG</span>
          </div>
        </div>

        {/* Decorative Overlay */}
        <div className="absolute right-0 top-0 bottom-0 w-24 bg-gradient-to-l from-[#0a0e0d] to-transparent pointer-events-none"></div>
      </div>

      {/* Selected Position Inspector Bar */}
      {selectedPos && (
        <div className="bg-[#171d1c] p-3 px-6 border-t border-[#1f6e65]/20 flex flex-wrap items-center justify-between text-xs text-[#dee4e2]">
          <div className="flex items-center gap-4">
            <span className="flex items-center gap-1.5 font-semibold text-[#8bd4c9]">
              <Info className="w-4 h-4" />
              Inspector Position #{selectedPos}
            </span>
            <span>Ref: <strong className="text-[#ffb4ab] font-mono-code">C</strong></span>
            <span>Sample: <strong className="text-[#8bd4c9] font-mono-code">T</strong></span>
            <span className="text-[#9baba8]">Codon: <code className="text-[#dee4e2]">GGA -&gt; GAA</code></span>
            <span className="text-[#9baba8]">AA: <code className="text-[#a6f0e5]">Gly2553Glu</code></span>
          </div>
          {onDeepAnalyzeVariant && (
            <button
              onClick={() => onDeepAnalyzeVariant(selectedPos, 'C', 'T')}
              className="bg-[#1f6e65] hover:bg-[#258277] text-[#a3ede2] px-3 py-1 rounded-lg flex items-center gap-1.5 text-xs font-medium transition-all active:scale-95 shadow-sm"
            >
              <Sparkles className="w-3.5 h-3.5" />
              <span>AI Deep Structure Predict</span>
            </button>
          )}
        </div>
      )}
    </div>
  );
};
