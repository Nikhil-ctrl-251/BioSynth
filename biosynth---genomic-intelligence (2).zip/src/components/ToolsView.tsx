import React, { useState } from 'react';
import { Wrench, Sparkles, Copy, Check, Download, Loader2, RefreshCw } from 'lucide-react';

export const ToolsView: React.FC = () => {
  const [task, setTask] = useState('PCR Primer Design & Assembly');
  const [targetGene, setTargetGene] = useState('Alpha-Fold Variant Exon 2');
  const [targetLength, setTargetLength] = useState('120');
  const [gcTarget, setGcTarget] = useState('50%');
  const [restrictionSites, setRestrictionSites] = useState('Include EcoRI (GAATTC)');

  const [synthesizing, setSynthesizing] = useState(false);
  const [result, setResult] = useState<{
    sequence: string;
    gcContent: number;
    meltingTemp: string;
    notes: string;
  } | null>({
    sequence: 'ATCGGCTAGCTAGCTAGCTAGCTAGCTAGCTAGCTAGCTAGCTAGCTAGCTAGCACGATCGGCTAGCTAGCTAGCTAGCTAGCTAGCTAG',
    gcContent: 52.4,
    meltingTemp: '62.5 °C',
    notes: 'Generated 90bp synthetic primer pair flanking the Gly2553Glu site with optimal melting temperature.'
  });

  const [copied, setCopied] = useState(false);

  const handleSynthesize = async (e: React.FormEvent) => {
    e.preventDefault();
    setSynthesizing(true);
    try {
      const res = await fetch('/api/ai/synthesize-sequence', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          task,
          targetGene,
          targetLength: parseInt(targetLength, 10) || 120,
          GCContentTarget: gcTarget,
          restrictionSites
        })
      });
      const data = await res.json();
      setResult({
        sequence: data.sequence || 'ATCGATCGATCGATCG',
        gcContent: data.gcContent || 50,
        meltingTemp: data.meltingTemp || '60.0 °C',
        notes: data.notes || 'Sequence generated.'
      });
    } catch (err) {
      console.error('Synthesis failed:', err);
    } finally {
      setSynthesizing(false);
    }
  };

  const handleCopy = () => {
    if (result) {
      navigator.clipboard.writeText(result.sequence);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-[#1a2321] rounded-2xl p-6 glow-effect border border-[#1f6e65]/10">
        <h2 className="font-serif-heading text-xl text-[#e0e6e4] font-bold flex items-center gap-2">
          <Wrench className="w-6 h-6 text-[#8bd4c9]" />
          <span>Synthetic Sequence &amp; Primer Design Workbench</span>
        </h2>
        <p className="text-xs text-[#9baba8] mt-1">
          AI-assisted DNA sequence synthesis, primer melting temp calculations, and restriction site mapping.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Input Parameters Form */}
        <div className="lg:col-span-5 bg-[#1a2321] rounded-2xl p-6 glow-effect border border-[#1f6e65]/10">
          <h3 className="font-serif-heading text-lg text-[#e0e6e4] font-semibold mb-4 flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-[#8bd4c9]" />
            <span>Synthesis Specification</span>
          </h3>

          <form onSubmit={handleSynthesize} className="space-y-4 text-xs">
            <div>
              <label className="block text-[#bec9c6] font-medium mb-1">Target Application / Task</label>
              <select
                value={task}
                onChange={(e) => setTask(e.target.value)}
                className="w-full bg-[#171d1c] border border-[#3f4947]/40 rounded-xl px-3.5 py-2 text-[#dee4e2] focus:outline-none focus:border-[#8bd4c9]"
              >
                <option value="PCR Primer Design & Assembly">PCR Primer Design &amp; Assembly</option>
                <option value="CRISPR gRNA Target Design">CRISPR gRNA Target Design</option>
                <option value="Synthetic Plasmid Insert">Synthetic Plasmid Insert</option>
                <option value="Codon Optimization Stream">Codon Optimization Stream</option>
              </select>
            </div>

            <div>
              <label className="block text-[#bec9c6] font-medium mb-1">Target Gene / Context</label>
              <input
                type="text"
                value={targetGene}
                onChange={(e) => setTargetGene(e.target.value)}
                className="w-full bg-[#171d1c] border border-[#3f4947]/40 rounded-xl px-3.5 py-2 text-[#dee4e2] focus:outline-none focus:border-[#8bd4c9]"
              />
            </div>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-[#bec9c6] font-medium mb-1">Target Length (bp)</label>
                <input
                  type="number"
                  value={targetLength}
                  onChange={(e) => setTargetLength(e.target.value)}
                  className="w-full bg-[#171d1c] border border-[#3f4947]/40 rounded-xl px-3.5 py-2 text-[#dee4e2] focus:outline-none focus:border-[#8bd4c9]"
                />
              </div>
              <div>
                <label className="block text-[#bec9c6] font-medium mb-1">Desired GC Content</label>
                <input
                  type="text"
                  value={gcTarget}
                  onChange={(e) => setGcTarget(e.target.value)}
                  className="w-full bg-[#171d1c] border border-[#3f4947]/40 rounded-xl px-3.5 py-2 text-[#dee4e2] focus:outline-none focus:border-[#8bd4c9]"
                />
              </div>
            </div>

            <div>
              <label className="block text-[#bec9c6] font-medium mb-1">Restriction Sites Constraints</label>
              <input
                type="text"
                value={restrictionSites}
                onChange={(e) => setRestrictionSites(e.target.value)}
                className="w-full bg-[#171d1c] border border-[#3f4947]/40 rounded-xl px-3.5 py-2 text-[#dee4e2] focus:outline-none focus:border-[#8bd4c9]"
              />
            </div>

            <button
              type="submit"
              disabled={synthesizing}
              className="w-full bg-[#1f6e65] hover:bg-[#258277] text-[#a3ede2] py-2.5 rounded-xl font-medium flex items-center justify-center gap-2 btn-primary-glow transition-all mt-4"
            >
              {synthesizing ? (
                <Loader2 className="w-4 h-4 animate-spin" />
              ) : (
                <Sparkles className="w-4 h-4" />
              )}
              <span>Synthesize Sequence with Gemini</span>
            </button>
          </form>
        </div>

        {/* Output Panel */}
        <div className="lg:col-span-7 bg-[#1a2321] rounded-2xl p-6 glow-effect border border-[#1f6e65]/10 flex flex-col justify-between">
          <div>
            <div className="flex justify-between items-center mb-4">
              <h3 className="font-serif-heading text-lg text-[#e0e6e4] font-semibold">
                Synthesized Nucleotide Result
              </h3>
              {result && (
                <div className="flex gap-2">
                  <button
                    onClick={handleCopy}
                    className="text-xs bg-[#252b2a] hover:bg-[#343a39] text-[#dee4e2] px-3 py-1.5 rounded-lg flex items-center gap-1.5 border border-[#3f4947]/30"
                  >
                    {copied ? <Check className="w-3.5 h-3.5 text-[#8bd4c9]" /> : <Copy className="w-3.5 h-3.5" />}
                    <span>{copied ? 'Copied!' : 'Copy FASTA'}</span>
                  </button>
                </div>
              )}
            </div>

            {synthesizing ? (
              <div className="py-20 flex flex-col items-center justify-center gap-3 text-center">
                <Loader2 className="w-8 h-8 text-[#8bd4c9] animate-spin" />
                <p className="text-xs text-[#9baba8]">Generating optimized FASTA sequence...</p>
              </div>
            ) : result ? (
              <div className="space-y-4">
                <div className="grid grid-cols-2 gap-3 text-xs">
                  <div className="bg-[#171d1c] p-3 rounded-xl border border-[#3f4947]/20">
                    <p className="text-[#9baba8] text-[10px] uppercase">GC Content</p>
                    <p className="text-lg font-serif-heading text-[#8bd4c9] font-bold">
                      {result.gcContent}%
                    </p>
                  </div>
                  <div className="bg-[#171d1c] p-3 rounded-xl border border-[#3f4947]/20">
                    <p className="text-[#9baba8] text-[10px] uppercase">Melting Temp (Tm)</p>
                    <p className="text-lg font-serif-heading text-[#a3ede2] font-bold">
                      {result.meltingTemp}
                    </p>
                  </div>
                </div>

                <div>
                  <p className="text-xs text-[#9baba8] mb-1.5 font-medium">FASTA Nucleotide Chain:</p>
                  <div className="bg-[#0a0e0d] p-4 rounded-xl border border-[#3f4947]/30 font-mono-code text-xs text-[#8bd4c9] leading-relaxed break-all max-h-48 overflow-y-auto">
                    {result.sequence}
                  </div>
                </div>

                <div className="bg-[#171d1c] p-3.5 rounded-xl border border-[#3f4947]/20 text-xs text-[#bec9c6]">
                  <p className="font-semibold text-[#dee4e2] mb-1">Design Notes:</p>
                  <p className="leading-relaxed">{result.notes}</p>
                </div>
              </div>
            ) : (
              <p className="text-xs text-[#9baba8]">Configure parameters and click synthesize.</p>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
