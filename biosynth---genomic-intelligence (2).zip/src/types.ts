export type TabType = 'analysis' | 'variation' | 'biology' | 'tools';

export interface SequenceData {
  referenceName: string;
  referenceBp: number;
  referenceSeq: string;
  sampleName: string;
  sampleBp: number;
  sampleSeq: string;
}

export interface AlignmentMetrics {
  identity: number;
  coverage: number;
  substitutions: number;
  insertions: number;
  deletions: number;
  gapOpen: number;
  gapExtend: number;
  algorithm: 'Needleman-Wunsch (Global)' | 'Smith-Waterman (Local)';
}

export interface VariantItem {
  id: string;
  title: string;
  type: 'Missense Mutation' | 'Frameshift Insertion' | 'Synonymous' | 'Deletion' | 'Nonsense';
  posStart: number;
  posEnd: number;
  refSeq: string;
  altSeq: string;
  codonChange: string;
  aminoAcidChange: string;
  severity: 'high' | 'moderate' | 'low' | 'modifier';
  description: string;
  siftScore?: number;
  polyphenScore?: number;
}

export interface EvidenceMetadata {
  alignmentMethod: string;
  gapPenalty: string;
  referenceGenome: string;
  annotationSource: string;
  analysisDate: string;
  qualityScore: number;
}

export interface Experiment {
  id: string;
  name: string;
  project: string;
  referenceName: string;
  sampleName: string;
  referenceBp: number;
  sampleBp: number;
  lastSynced: string;
  qualityScore: number;
}
