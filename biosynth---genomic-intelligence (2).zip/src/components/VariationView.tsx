import React, { useState } from 'react';
import { GitBranch, Search, Filter, AlertTriangle, CheckCircle, Info, Sparkles } from 'lucide-react';
import { VariantItem } from '../types';

interface VariationViewProps {
  variants: VariantItem[];
  onAnalyzeVariant?: (variant: VariantItem) => void;
}

export const VariationView: React.FC<VariationViewProps> = ({ variants, onAnalyzeVariant }) => {
  const [filterType, setFilterType] = useState<string>('all');
  const [searchTerm, setSearchTerm] = useState<string>('');
  const [selectedVariant, setSelectedVariant] = useState<VariantItem | null>(variants[0] || null);

  const filtered = variants.filter((v) => {
    const matchesFilter = filterType === 'all' || v.type.toLowerCase().includes(filterType.toLowerCase());
    const matchesSearch =
      v.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      v.codonChange.toLowerCase().includes(searchTerm.toLowerCase()) ||
      v.posStart.toString().includes(searchTerm);
    return matchesFilter && matchesSearch;
  });

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="bg-[#1a2321] rounded-2xl p-6 glow-effect border border-[#1f6e65]/10 flex flex-wrap justify-between items-center gap-4">
        <div>
          <h2 className="font-serif-heading text-xl text-[#e0e6e4] font-bold flex items-center gap-2">
            <GitBranch className="w-6 h-6 text-[#8bd4c9]" />
            <span>Genomic Variation Index</span>
          </h2>
          <p className="text-xs text-[#9baba8] mt-1">
            Comprehensive catalog of single nucleotide polymorphisms (SNPs), insertions, and deletions.
          </p>
        </div>

        {/* Filter Controls */}
        <div className="flex flex-wrap items-center gap-3 text-xs">
          <div className="relative">
            <Search className="w-3.5 h-3.5 absolute left-3 top-1/2 -translate-y-1/2 text-[#bec9c6]" />
            <input
              type="text"
              placeholder="Search pos, codon, title..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="bg-[#171d1c] border border-[#3f4947]/30 text-[#dee4e2] rounded-full py-1.5 pl-8 pr-3 text-xs focus:outline-none focus:border-[#8bd4c9]"
            />
          </div>

          <div className="flex items-center bg-[#171d1c] border border-[#3f4947]/30 rounded-full p-1 gap-1">
            <button
              onClick={() => setFilterType('all')}
              className={`px-3 py-1 rounded-full font-medium transition-all ${
                filterType === 'all'
                  ? 'bg-[#1f6e65] text-[#a3ede2]'
                  : 'text-[#bec9c6] hover:text-[#dee4e2]'
              }`}
            >
              All ({variants.length})
            </button>
            <button
              onClick={() => setFilterType('missense')}
              className={`px-3 py-1 rounded-full font-medium transition-all ${
                filterType === 'missense'
                  ? 'bg-[#1f6e65] text-[#a3ede2]'
                  : 'text-[#bec9c6] hover:text-[#dee4e2]'
              }`}
            >
              Missense
            </button>
            <button
              onClick={() => setFilterType('frameshift')}
              className={`px-3 py-1 rounded-full font-medium transition-all ${
                filterType === 'frameshift'
                  ? 'bg-[#1f6e65] text-[#a3ede2]'
                  : 'text-[#bec9c6] hover:text-[#dee4e2]'
              }`}
            >
              Frameshift
            </button>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Variant Table */}
        <div className="lg:col-span-7 bg-[#1a2321] rounded-2xl p-6 glow-effect border border-[#1f6e65]/10 overflow-hidden">
          <h3 className="font-serif-heading text-lg text-[#e0e6e4] font-semibold mb-4">
            Detected Variations ({filtered.length})
          </h3>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="border-b border-[#3f4947]/30 text-[#9baba8] uppercase tracking-wider">
                  <th className="pb-3 font-semibold">Position</th>
                  <th className="pb-3 font-semibold">Type</th>
                  <th className="pb-3 font-semibold">Ref &rarr; Alt</th>
                  <th className="pb-3 font-semibold">Codon</th>
                  <th className="pb-3 font-semibold">Severity</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#3f4947]/20">
                {filtered.map((v) => {
                  const isSelected = selectedVariant?.id === v.id;
                  return (
                    <tr
                      key={v.id}
                      onClick={() => setSelectedVariant(v)}
                      className={`cursor-pointer transition-colors ${
                        isSelected ? 'bg-[#1f6e65]/20 font-medium' : 'hover:bg-[#171d1c]'
                      }`}
                    >
                      <td className="py-3 font-mono-code text-[#dee4e2]">{v.posStart}</td>
                      <td className="py-3">
                        <span className="text-[#a3ede2] font-medium">{v.type}</span>
                      </td>
                      <td className="py-3 font-mono-code">
                        <span className="text-[#ffb4ab]">{v.refSeq}</span> &rarr;{' '}
                        <span className="text-[#8bd4c9]">{v.altSeq}</span>
                      </td>
                      <td className="py-3 font-mono-code text-[#bec9c6]">{v.codonChange}</td>
                      <td className="py-3">
                        <span
                          className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase ${
                            v.severity === 'high'
                              ? 'bg-[#ffb4ab]/20 text-[#ffb4ab]'
                              : v.severity === 'moderate'
                              ? 'bg-[#ffdbd0]/20 text-[#ffb59d]'
                              : 'bg-[#a3ede2]/20 text-[#a3ede2]'
                          }`}
                        >
                          {v.severity}
                        </span>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>

        {/* Selected Variant Inspector */}
        <div className="lg:col-span-5 bg-[#1a2321] rounded-2xl p-6 glow-effect border border-[#1f6e65]/10 flex flex-col justify-between">
          {selectedVariant ? (
            <div>
              <div className="flex justify-between items-start mb-4">
                <div>
                  <span className="text-[10px] bg-[#1f6e65]/30 text-[#a3ede2] px-2 py-0.5 rounded uppercase tracking-wider font-semibold">
                    Position #{selectedVariant.posStart}
                  </span>
                  <h3 className="font-serif-heading text-xl text-[#e0e6e4] font-bold mt-1">
                    {selectedVariant.title}
                  </h3>
                </div>
                <span className="text-xs font-mono-code text-[#8bd4c9]">
                  {selectedVariant.type}
                </span>
              </div>

              <div className="bg-[#171d1c] p-4 rounded-xl border border-[#3f4947]/30 space-y-3 text-xs mb-4">
                <div className="flex justify-between">
                  <span className="text-[#9baba8]">Reference Allele:</span>
                  <strong className="text-[#ffb4ab] font-mono-code">{selectedVariant.refSeq}</strong>
                </div>
                <div className="flex justify-between">
                  <span className="text-[#9baba8]">Sample Allele:</span>
                  <strong className="text-[#8bd4c9] font-mono-code">{selectedVariant.altSeq}</strong>
                </div>
                <div className="flex justify-between">
                  <span className="text-[#9baba8]">Codon Shift:</span>
                  <strong className="text-[#dee4e2] font-mono-code">{selectedVariant.codonChange}</strong>
                </div>
                <div className="flex justify-between">
                  <span className="text-[#9baba8]">Amino Acid Effect:</span>
                  <strong className="text-[#a6f0e5] font-mono-code">{selectedVariant.aminoAcidChange || 'N/A'}</strong>
                </div>
              </div>

              <p className="text-xs text-[#bec9c6] leading-relaxed bg-[#171d1c]/50 p-3 rounded-lg mb-4 border border-[#3f4947]/20">
                {selectedVariant.description}
              </p>

              {/* SIFT & PolyPhen Scores */}
              <div className="grid grid-cols-2 gap-3 mb-4">
                <div className="bg-[#171d1c] p-3 rounded-xl border border-[#3f4947]/20 text-center">
                  <p className="text-[10px] text-[#9baba8] uppercase">SIFT Score</p>
                  <p className="text-lg font-serif-heading font-bold text-[#ffb4ab]">
                    {selectedVariant.siftScore ?? '0.02'}
                  </p>
                  <p className="text-[10px] text-[#9baba8]">Damaging (&lt;0.05)</p>
                </div>
                <div className="bg-[#171d1c] p-3 rounded-xl border border-[#3f4947]/20 text-center">
                  <p className="text-[10px] text-[#9baba8] uppercase">PolyPhen-2</p>
                  <p className="text-lg font-serif-heading font-bold text-[#ffb59d]">
                    {selectedVariant.polyphenScore ?? '0.89'}
                  </p>
                  <p className="text-[10px] text-[#9baba8]">Probably Damaging</p>
                </div>
              </div>

              {onAnalyzeVariant && (
                <button
                  onClick={() => onAnalyzeVariant(selectedVariant)}
                  className="w-full bg-[#1f6e65] hover:bg-[#258277] text-[#a3ede2] py-2.5 rounded-xl font-medium text-xs flex items-center justify-center gap-2 btn-primary-glow transition-all"
                >
                  <Sparkles className="w-4 h-4" />
                  <span>Run Predictive AI Protein Model</span>
                </button>
              )}
            </div>
          ) : (
            <p className="text-xs text-[#9baba8]">Select a variant from table to inspect</p>
          )}
        </div>
      </div>
    </div>
  );
};
