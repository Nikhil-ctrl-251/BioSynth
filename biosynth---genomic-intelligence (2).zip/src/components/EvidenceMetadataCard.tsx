import React from 'react';
import { Database } from 'lucide-react';
import { EvidenceMetadata } from '../types';

interface EvidenceMetadataCardProps {
  metadata: EvidenceMetadata;
}

export const EvidenceMetadataCard: React.FC<EvidenceMetadataCardProps> = ({ metadata }) => {
  return (
    <div className="bg-[#1a2321] rounded-2xl p-6 glow-effect border border-[#1f6e65]/10 flex flex-col justify-between h-full">
      <div>
        <h3 className="font-serif-heading text-lg text-[#e0e6e4] font-semibold mb-4 flex items-center gap-2">
          <Database className="w-5 h-5 text-[#bec9c6]" />
          <span>Evidence &amp; Metadata</span>
        </h3>

        <div className="grid grid-cols-2 gap-y-5 gap-x-4">
          <div>
            <p className="text-[11px] text-[#9baba8] uppercase tracking-wider mb-0.5">Alignment Method</p>
            <p className="font-medium text-sm text-[#dee4e2]">{metadata.alignmentMethod}</p>
            <p className="text-xs text-[#bec9c6] mt-0.5 font-mono-code">{metadata.gapPenalty}</p>
          </div>

          <div>
            <p className="text-[11px] text-[#9baba8] uppercase tracking-wider mb-0.5">Reference Genome</p>
            <p className="font-medium text-sm text-[#dee4e2]">{metadata.referenceGenome}</p>
          </div>

          <div>
            <p className="text-[11px] text-[#9baba8] uppercase tracking-wider mb-0.5">Annotation Source</p>
            <p className="font-medium text-sm text-[#dee4e2]">{metadata.annotationSource}</p>
          </div>

          <div>
            <p className="text-[11px] text-[#9baba8] uppercase tracking-wider mb-0.5">Analysis Date</p>
            <p className="font-medium text-sm text-[#dee4e2] font-mono-code">{metadata.analysisDate}</p>
          </div>
        </div>
      </div>

      <div className="mt-6 p-4 bg-[#171d1c] rounded-xl border border-[#3f4947]/20">
        <div className="flex justify-between items-center text-sm">
          <span className="text-[#bec9c6]">Data Quality Score</span>
          <span className="font-bold text-[#8bd4c9] font-mono-code">{metadata.qualityScore}/100</span>
        </div>
        <div className="w-full bg-[#303635] h-1.5 rounded-full mt-2.5 overflow-hidden">
          <div
            className="bg-[#8bd4c9] h-full rounded-full transition-all duration-500 shadow-[0_0_10px_rgba(139,212,201,0.5)]"
            style={{ width: `${metadata.qualityScore}%` }}
          ></div>
        </div>
      </div>
    </div>
  );
};
