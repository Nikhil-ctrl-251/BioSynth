import React, { useState } from 'react';
import { Sidebar } from './components/Sidebar';
import { Header } from './components/Header';
import { SequenceAlignmentSetup } from './components/SequenceAlignmentSetup';
import { AlignmentMetricsCard } from './components/AlignmentMetricsCard';
import { GlobalVariationMap } from './components/GlobalVariationMap';
import { SequenceViewer } from './components/SequenceViewer';
import { PredictedImpactPanel } from './components/PredictedImpactPanel';
import { EvidenceMetadataCard } from './components/EvidenceMetadataCard';
import { VariationView } from './components/VariationView';
import { BiologyView } from './components/BiologyView';
import { ToolsView } from './components/ToolsView';
import { NewExperimentModal } from './components/NewExperimentModal';
import { ExecutiveReportModal } from './components/ExecutiveReportModal';
import {
  INITIAL_EXPERIMENT,
  INITIAL_METRICS,
  INITIAL_METADATA,
  INITIAL_VARIANTS,
  INITIAL_SEQUENCE_DATA,
  SAMPLE_EXPERIMENTS
} from './data/mockGenome';
import { AlignmentMetrics, Experiment, SequenceData, TabType, VariantItem } from './types';
import { Menu } from 'lucide-react';

export default function App() {
  const [activeTab, setActiveTab] = useState<TabType>('analysis');
  const [currentExperiment, setCurrentExperiment] = useState<Experiment>(INITIAL_EXPERIMENT);
  const [sequenceData, setSequenceData] = useState<SequenceData>(INITIAL_SEQUENCE_DATA);
  const [metrics, setMetrics] = useState<AlignmentMetrics>(INITIAL_METRICS);
  const [variants, setVariants] = useState<VariantItem[]>(INITIAL_VARIANTS);
  const [metadata, setMetadata] = useState(INITIAL_METADATA);

  const [experimentsList, setExperimentsList] = useState<Experiment[]>(SAMPLE_EXPERIMENTS);
  const [viewPos, setViewPos] = useState<number>(2540);

  // Modals state
  const [isNewExpOpen, setIsNewExpOpen] = useState<boolean>(false);
  const [isReportOpen, setIsReportOpen] = useState<boolean>(false);
  const [isMobileNavOpen, setIsMobileNavOpen] = useState<boolean>(false);

  // Swap Inputs Handler
  const handleSwapInputs = () => {
    setSequenceData((prev) => ({
      ...prev,
      referenceName: prev.sampleName,
      referenceBp: prev.sampleBp,
      referenceSeq: prev.sampleSeq,
      sampleName: prev.referenceName,
      sampleBp: prev.referenceBp,
      sampleSeq: prev.referenceSeq
    }));
  };

  // Select experiment handler
  const handleSelectExperiment = (exp: Experiment) => {
    setCurrentExperiment(exp);
    setSequenceData((prev) => ({
      ...prev,
      referenceName: exp.referenceName,
      referenceBp: exp.referenceBp,
      sampleName: exp.sampleName,
      sampleBp: exp.sampleBp
    }));
  };

  const handleCreateCustomExperiment = (exp: Experiment) => {
    setExperimentsList((prev) => [exp, ...prev]);
    handleSelectExperiment(exp);
  };

  return (
    <div className="bg-[#0f1514] text-[#dee4e2] font-sans min-h-screen flex selection:bg-[#1f6e65] selection:text-[#a3ede2]">
      {/* Mobile Header Toggle */}
      <div className="md:hidden fixed top-4 left-4 z-50">
        <button
          onClick={() => setIsMobileNavOpen(true)}
          className="p-2 bg-[#1a2321] border border-[#1f6e65]/30 rounded-xl text-[#8bd4c9] shadow-lg"
        >
          <Menu className="w-5 h-5" />
        </button>
      </div>

      {/* Sidebar Navigation */}
      <Sidebar
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        onNewExperiment={() => setIsNewExpOpen(true)}
        isMobileOpen={isMobileNavOpen}
        setIsMobileOpen={setIsMobileNavOpen}
      />

      {/* Main Content Area */}
      <main className="flex-1 ml-0 md:ml-[280px] min-h-screen flex flex-col relative w-full">
        <Header
          currentExperiment={currentExperiment}
          onOpenNewExperiment={() => setIsNewExpOpen(true)}
          onOpenExecutiveReport={() => setIsReportOpen(true)}
        />

        {/* Workbench Canvas */}
        <div className="p-4 sm:p-6 lg:p-8 pb-20 flex flex-col gap-6 max-w-[1200px] mx-auto w-full">
          {activeTab === 'analysis' && (
            <>
              {/* Grid Row 1: Setup (7 cols) + Metrics (5 cols) */}
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-stretch">
                <div className="lg:col-span-7">
                  <SequenceAlignmentSetup
                    sequenceData={sequenceData}
                    onSwapInputs={handleSwapInputs}
                  />
                </div>
                <div className="lg:col-span-5">
                  <AlignmentMetricsCard
                    metrics={metrics}
                    onAlgorithmChange={(alg) =>
                      setMetrics((m) => ({ ...m, algorithm: alg }))
                    }
                  />
                </div>
              </div>

              {/* Grid Row 2: Difference Map (Navigable Track) */}
              <GlobalVariationMap
                viewPosition={viewPos}
                onPositionSelect={(pos) => setViewPos(pos)}
                totalLength={sequenceData.referenceBp}
              />

              {/* Grid Row 3: Hero Alignment Viewer */}
              <SequenceViewer
                sequenceData={sequenceData}
                startPos={viewPos}
                onSelectBase={(pos) => setViewPos(pos)}
              />

              {/* Grid Row 4: Functional Impact (6 cols) + Evidence & Metadata (6 cols) */}
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 items-stretch">
                <PredictedImpactPanel variants={variants} />
                <EvidenceMetadataCard metadata={metadata} />
              </div>
            </>
          )}

          {activeTab === 'variation' && (
            <VariationView
              variants={variants}
              onAnalyzeVariant={() => setIsReportOpen(true)}
            />
          )}

          {activeTab === 'biology' && <BiologyView />}

          {activeTab === 'tools' && <ToolsView />}
        </div>
      </main>

      {/* Modals */}
      <NewExperimentModal
        isOpen={isNewExpOpen}
        onClose={() => setIsNewExpOpen(false)}
        onSelectExperiment={handleSelectExperiment}
        onCreateCustomExperiment={handleCreateCustomExperiment}
        availableExperiments={experimentsList}
        currentExperimentId={currentExperiment.id}
      />

      <ExecutiveReportModal
        isOpen={isReportOpen}
        onClose={() => setIsReportOpen(false)}
        experiment={currentExperiment}
        metrics={metrics}
        variants={variants}
      />
    </div>
  );
}
