import React, { useState } from 'react';
import { ArrowLeftRight, FileText, FlaskConical, MoreVertical, Upload } from 'lucide-react';
import { SequenceData } from '../types';

interface SequenceAlignmentSetupProps {
  sequenceData: SequenceData;
  onSwapInputs: () => void;
  onUploadFile?: (type: 'ref' | 'sample', file: File) => void;
}

export const SequenceAlignmentSetup: React.FC<SequenceAlignmentSetupProps> = ({
  sequenceData,
  onSwapInputs
}) => {
  const [showRefMenu, setShowRefMenu] = useState(false);
  const [showSampleMenu, setShowSampleMenu] = useState(false);

  return (
    <div className="bg-[#1a2321] rounded-2xl p-6 glow-effect border border-[#1f6e65]/10 relative overflow-hidden">
      <div className="absolute top-0 right-0 w-64 h-64 bg-[#8bd4c9]/5 rounded-full blur-[80px] -translate-y-1/2 translate-x-1/4 pointer-events-none"></div>

      <div className="flex justify-between items-center mb-6">
        <h3 className="font-serif-heading text-lg text-[#e0e6e4] font-semibold">
          Sequence Alignment Setup
        </h3>
        <button
          onClick={onSwapInputs}
          className="text-[#8bd4c9] hover:text-[#a6f0e5] transition-colors flex items-center gap-1.5 font-medium text-xs sm:text-sm bg-[#1f6e65]/10 hover:bg-[#1f6e65]/20 px-3 py-1.5 rounded-lg border border-[#1f6e65]/30 active:scale-95"
        >
          <ArrowLeftRight className="w-4 h-4" />
          <span>Swap Inputs</span>
        </button>
      </div>

      <div className="flex flex-col md:flex-row gap-4 items-stretch relative">
        {/* Target A: Reference */}
        <div className="flex-1 bg-[#171d1c] rounded-xl p-4 border border-[#3f4947]/30 hover:border-[#1f6e65]/40 transition-colors group relative">
          <div className="flex justify-between items-start mb-3">
            <span className="bg-[#303635] text-[#bec9c6] text-[11px] uppercase tracking-wider px-2 py-0.5 rounded-md font-semibold">
              Reference
            </span>
            <button
              onClick={() => setShowRefMenu(!showRefMenu)}
              className="text-[#bec9c6] hover:text-[#dee4e2] opacity-70 group-hover:opacity-100 transition-opacity"
            >
              <MoreVertical className="w-4 h-4" />
            </button>
          </div>

          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-full bg-[#303635] flex items-center justify-center text-[#8bd4c9] shrink-0">
              <FileText className="w-5 h-5" />
            </div>
            <div className="overflow-hidden">
              <h4 className="font-medium text-sm text-[#dee4e2] truncate" title={sequenceData.referenceName}>
                {sequenceData.referenceName}
              </h4>
              <p className="text-xs text-[#9baba8] font-mono-code mt-0.5">
                {sequenceData.referenceBp.toLocaleString()} bp
              </p>
            </div>
          </div>

          {showRefMenu && (
            <div className="absolute right-4 top-10 w-48 bg-[#1a2321] border border-[#1f6e65]/30 rounded-xl shadow-xl p-2 z-30 text-xs">
              <label className="flex items-center gap-2 p-2 hover:bg-[#303635] rounded-lg cursor-pointer text-[#dee4e2]">
                <Upload className="w-3.5 h-3.5 text-[#8bd4c9]" />
                <span>Upload FASTA</span>
                <input
                  type="file"
                  accept=".fasta,.fa,.txt"
                  className="hidden"
                  onChange={(e) => {
                    if (e.target.files?.[0]) {
                      alert(`Loaded reference: ${e.target.files[0].name}`);
                      setShowRefMenu(false);
                    }
                  }}
                />
              </label>
              <button
                onClick={() => {
                  alert("Swapping to standard Human Reference GRCh38.p13");
                  setShowRefMenu(false);
                }}
                className="w-full text-left p-2 hover:bg-[#303635] rounded-lg text-[#dee4e2]"
              >
                Load GRCh38 Default
              </button>
            </div>
          )}
        </div>

        {/* VS Divider */}
        <div className="flex items-center justify-center shrink-0">
          <div className="w-8 h-8 rounded-full bg-[#1b2120] flex items-center justify-center text-[#bec9c6] border border-[#3f4947]/30 z-10 shadow-md">
            <span className="text-xs font-bold font-sans">VS</span>
          </div>
          <div className="hidden md:block absolute h-px bg-[#3f4947]/30 w-12 left-1/2 -translate-x-1/2 z-0"></div>
        </div>

        {/* Target B: Sample Query */}
        <div className="flex-1 bg-[#171d1c] rounded-xl p-4 border border-[#1f6e65]/40 hover:border-[#1f6e65]/60 transition-colors relative overflow-hidden group">
          {/* Active indicator pulse */}
          <div className="absolute top-4 right-4 flex items-center gap-2">
            <span className="text-[10px] text-[#8bd4c9] uppercase tracking-widest font-bold">Query</span>
            <span className="relative flex h-2 w-2">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-[#8bd4c9] opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2 w-2 bg-[#8bd4c9]"></span>
            </span>
          </div>

          <div className="mb-3">
            <span className="bg-[#1f6e65]/20 text-[#8bd4c9] text-[11px] uppercase tracking-wider px-2 py-0.5 rounded-md font-semibold border border-[#1f6e65]/30">
              Sample
            </span>
          </div>

          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-full bg-[#1f6e65]/30 flex items-center justify-center text-[#8bd4c9] shrink-0">
              <FlaskConical className="w-5 h-5" />
            </div>
            <div className="overflow-hidden">
              <h4 className="font-medium text-sm text-[#dee4e2] truncate" title={sequenceData.sampleName}>
                {sequenceData.sampleName}
              </h4>
              <p className="text-xs text-[#9baba8] font-mono-code mt-0.5">
                {sequenceData.sampleBp.toLocaleString()} bp
              </p>
            </div>
          </div>

          {showSampleMenu && (
            <div className="absolute right-4 top-10 w-48 bg-[#1a2321] border border-[#1f6e65]/30 rounded-xl shadow-xl p-2 z-30 text-xs">
              <label className="flex items-center gap-2 p-2 hover:bg-[#303635] rounded-lg cursor-pointer text-[#dee4e2]">
                <Upload className="w-3.5 h-3.5 text-[#8bd4c9]" />
                <span>Upload Sample FASTA</span>
                <input
                  type="file"
                  accept=".fasta,.fa,.txt"
                  className="hidden"
                  onChange={(e) => {
                    if (e.target.files?.[0]) {
                      alert(`Loaded sample: ${e.target.files[0].name}`);
                      setShowSampleMenu(false);
                    }
                  }}
                />
              </label>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
