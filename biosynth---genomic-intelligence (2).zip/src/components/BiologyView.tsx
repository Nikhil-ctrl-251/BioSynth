import React, { useState } from 'react';
import { FlaskConical, Dna, Layers, Zap, Info } from 'lucide-react';

export const BiologyView: React.FC = () => {
  const [selectedDomain, setSelectedDomain] = useState<string>('Domain II: Hydrophobic Core');
  const [codonInput, setCodonInput] = useState<string>('GGA');

  const codonTable: Record<string, string> = {
    GGA: 'Glycine (Gly)',
    GAA: 'Glutamic Acid (Glu)',
    CTA: 'Leucine (Leu)',
    CTG: 'Leucine (Leu)',
    GTC: 'Valine (Val)',
    ATC: 'Isoleucine (Ile)',
    ATG: 'Methionine (Start)',
    TAA: 'STOP',
    TAG: 'STOP',
    TGA: 'STOP'
  };

  return (
    <div className="space-y-6">
      {/* Top Banner */}
      <div className="bg-[#1a2321] rounded-2xl p-6 glow-effect border border-[#1f6e65]/10">
        <h2 className="font-serif-heading text-xl text-[#e0e6e4] font-bold flex items-center gap-2">
          <FlaskConical className="w-6 h-6 text-[#8bd4c9]" />
          <span>Biological &amp; Structural Intelligence</span>
        </h2>
        <p className="text-xs text-[#9baba8] mt-1">
          Explore tertiary protein structure domain interactions and codon translation matrices.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Simulated AlphaFold 3D Interactive Domain Viewer */}
        <div className="lg:col-span-8 bg-[#1a2321] rounded-2xl p-6 glow-effect border border-[#1f6e65]/10 flex flex-col justify-between">
          <div className="flex justify-between items-center mb-4">
            <h3 className="font-serif-heading text-lg text-[#e0e6e4] font-semibold flex items-center gap-2">
              <Layers className="w-5 h-5 text-[#8bd4c9]" />
              <span>AlphaFold 3D Domain Structure</span>
            </h3>
            <span className="text-xs font-mono-code text-[#a3ede2] bg-[#1f6e65]/30 px-2.5 py-1 rounded-full">
              pLDDT: 94.2 (Very High)
            </span>
          </div>

          {/* 3D Visualizer Mock Stage */}
          <div className="relative w-full h-80 bg-[#0a0e0d] rounded-xl border border-[#3f4947]/30 flex items-center justify-center overflow-hidden">
            {/* Ambient Bioluminescent Glow */}
            <div className="absolute w-64 h-64 bg-[#1f6e65]/30 rounded-full blur-[90px]"></div>

            {/* Protein Backbone Helix Graphic (SVG animation) */}
            <svg className="w-full h-full max-w-md relative z-10" viewBox="0 0 400 200">
              {/* Alpha Helix ribbons */}
              <path
                d="M 20 100 Q 60 20 100 100 T 180 100 T 260 100 T 340 100"
                fill="none"
                stroke="#1f6e65"
                strokeWidth="12"
                strokeLinecap="round"
                opacity="0.6"
              />
              <path
                d="M 20 100 Q 60 20 100 100 T 180 100 T 260 100 T 340 100"
                fill="none"
                stroke="#8bd4c9"
                strokeWidth="4"
                strokeDasharray="8 4"
                className="animate-pulse"
              />

              {/* Mutation Hotspot Nodes */}
              <g className="cursor-pointer" onClick={() => setSelectedDomain('Position 2553: Gly2553Glu')}>
                <circle cx="180" cy="100" r="14" fill="#ffb4ab" opacity="0.3" />
                <circle cx="180" cy="100" r="7" fill="#ffb4ab" />
                <text x="180" y="80" textAnchor="middle" fill="#ffb4ab" fontSize="10" className="font-mono-code font-bold">
                  Gly2553Glu
                </text>
              </g>

              <g className="cursor-pointer" onClick={() => setSelectedDomain('Position 2566: Frameshift +GA')}>
                <circle cx="260" cy="100" r="14" fill="#a6f0e5" opacity="0.3" />
                <circle cx="260" cy="100" r="7" fill="#a6f0e5" />
                <text x="260" y="125" textAnchor="middle" fill="#a6f0e5" fontSize="10" className="font-mono-code font-bold">
                  +GA Frameshift
                </text>
              </g>
            </svg>

            {/* Controls Overlay */}
            <div className="absolute bottom-3 left-3 bg-[#171d1c]/80 backdrop-blur-md px-3 py-1.5 rounded-lg border border-[#3f4947]/30 text-[11px] text-[#9baba8] flex gap-3">
              <span>Domain: <strong className="text-[#dee4e2]">{selectedDomain}</strong></span>
              <span>Model: AlphaFold-v3</span>
            </div>
          </div>

          <div className="mt-4 grid grid-cols-3 gap-3 text-xs text-center">
            <div className="bg-[#171d1c] p-3 rounded-xl border border-[#3f4947]/20">
              <p className="text-[10px] text-[#9baba8]">Exon 1</p>
              <p className="font-semibold text-[#dee4e2]">Leader Peptide</p>
            </div>
            <div className="bg-[#171d1c] p-3 rounded-xl border border-[#1f6e65]/50">
              <p className="text-[10px] text-[#8bd4c9]">Exon 2 (Target)</p>
              <p className="font-semibold text-[#a3ede2]">Catalytic Domain</p>
            </div>
            <div className="bg-[#171d1c] p-3 rounded-xl border border-[#3f4947]/20">
              <p className="text-[10px] text-[#9baba8]">Exon 3</p>
              <p className="font-semibold text-[#dee4e2]">C-Terminal</p>
            </div>
          </div>
        </div>

        {/* Codon Translator & Reference Lookup */}
        <div className="lg:col-span-4 bg-[#1a2321] rounded-2xl p-6 glow-effect border border-[#1f6e65]/10 flex flex-col justify-between">
          <div>
            <h3 className="font-serif-heading text-lg text-[#e0e6e4] font-semibold mb-3 flex items-center gap-2">
              <Dna className="w-5 h-5 text-[#8bd4c9]" />
              <span>Codon Translator</span>
            </h3>

            <p className="text-xs text-[#9baba8] mb-4">
              Lookup amino acid residue translation from 3-base nucleotide codons.
            </p>

            <div className="space-y-4">
              <div>
                <label className="block text-xs text-[#bec9c6] mb-1">Enter Codon Triplet (DNA/RNA):</label>
                <input
                  type="text"
                  maxLength={3}
                  value={codonInput}
                  onChange={(e) => setCodonInput(e.target.value.toUpperCase())}
                  className="w-full bg-[#171d1c] border border-[#3f4947]/40 rounded-xl px-4 py-2.5 text-lg font-mono-code text-[#8bd4c9] uppercase tracking-widest focus:outline-none focus:border-[#8bd4c9]"
                />
              </div>

              <div className="bg-[#171d1c] p-4 rounded-xl border border-[#3f4947]/30 text-xs space-y-2">
                <p className="text-[#9baba8]">Translated Residue:</p>
                <p className="text-lg font-bold font-serif-heading text-[#a3ede2]">
                  {codonTable[codonInput] || 'Unknown Triplet'}
                </p>
              </div>

              <div className="bg-[#1f6e65]/15 border border-[#1f6e65]/30 p-3 rounded-xl text-xs space-y-1">
                <div className="flex items-center gap-1.5 font-semibold text-[#8bd4c9]">
                  <Zap className="w-4 h-4" />
                  <span>Workbench Insight</span>
                </div>
                <p className="text-[#bec9c6] text-[11px] leading-relaxed">
                  Substitution of <code>GGA</code> (Gly) to <code>GAA</code> (Glu) introduces a charged acidic side chain into the hydrophobic domain core, altering electrostatic potential.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
