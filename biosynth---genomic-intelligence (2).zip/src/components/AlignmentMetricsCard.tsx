import React from 'react';
import { ArrowUpRight } from 'lucide-react';
import { AlignmentMetrics } from '../types';

interface AlignmentMetricsCardProps {
  metrics: AlignmentMetrics;
  onAlgorithmChange?: (algorithm: 'Needleman-Wunsch (Global)' | 'Smith-Waterman (Local)') => void;
}

export const AlignmentMetricsCard: React.FC<AlignmentMetricsCardProps> = ({
  metrics,
  onAlgorithmChange
}) => {
  return (
    <div className="bg-[#1a2321] rounded-2xl p-6 glow-effect border border-[#1f6e65]/10 flex flex-col justify-between h-full">
      <div className="flex justify-between items-center mb-6">
        <h3 className="font-serif-heading text-lg text-[#e0e6e4] font-semibold">
          Alignment Metrics
        </h3>
        <button
          onClick={() => {
            const next = metrics.algorithm.includes('Global')
              ? 'Smith-Waterman (Local)'
              : 'Needleman-Wunsch (Global)';
            if (onAlgorithmChange) onAlgorithmChange(next);
          }}
          className="bg-[#3f4c49] hover:bg-[#1f6e65]/40 text-[#adbbb8] hover:text-[#a3ede2] text-xs px-2.5 py-1 rounded-md font-mono-code transition-colors border border-[#3f4947]/30"
          title="Click to toggle alignment mode"
        >
          {metrics.algorithm.includes('Global') ? 'Global Align' : 'Local Align'}
        </button>
      </div>

      <div className="grid grid-cols-2 gap-4 mb-6">
        <div className="bg-[#171d1c] p-4 rounded-xl border border-[#3f4947]/20">
          <p className="text-[#9baba8] text-xs mb-1">Identity</p>
          <div className="flex items-baseline gap-1.5">
            <p className="text-2xl font-serif-heading text-[#8bd4c9] font-bold">
              {metrics.identity.toFixed(2)}%
            </p>
            <ArrowUpRight className="w-4 h-4 text-[#8bd4c9]" />
          </div>
        </div>

        <div className="bg-[#171d1c] p-4 rounded-xl border border-[#3f4947]/20">
          <p className="text-[#9baba8] text-xs mb-1">Coverage</p>
          <p className="text-2xl font-serif-heading text-[#dee4e2] font-bold">
            {metrics.coverage.toFixed(2)}%
          </p>
        </div>
      </div>

      <div className="space-y-3">
        <div className="flex items-center justify-between py-2.5 border-t border-[#3f4947]/20">
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-[#ffb4ab]"></span>
            <span className="text-sm text-[#bec9c6]">Substitutions</span>
          </div>
          <span className="font-mono-code text-[#dee4e2] font-semibold text-sm">
            {metrics.substitutions}
          </span>
        </div>

        <div className="flex items-center justify-between py-2.5 border-t border-[#3f4947]/20">
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-[#a6f0e5]"></span>
            <span className="text-sm text-[#bec9c6]">Insertions</span>
          </div>
          <span className="font-mono-code text-[#dee4e2] font-semibold text-sm">
            {metrics.insertions}
          </span>
        </div>

        <div className="flex items-center justify-between py-2.5 border-t border-[#3f4947]/20">
          <div className="flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-[#303635] border border-[#889390]"></span>
            <span className="text-sm text-[#bec9c6]">Deletions</span>
          </div>
          <span className="font-mono-code text-[#dee4e2] font-semibold text-sm">
            {metrics.deletions}
          </span>
        </div>
      </div>
    </div>
  );
};
