import React, { useState } from 'react';
import { Search, Bell, Settings, HelpCircle, ChevronDown, Dna } from 'lucide-react';
import { Experiment } from '../types';

interface HeaderProps {
  currentExperiment: Experiment;
  onSearchChange?: (query: string) => void;
  onOpenNewExperiment: () => void;
  onOpenExecutiveReport: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  currentExperiment,
  onSearchChange,
  onOpenExecutiveReport
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [showProfileMenu, setShowProfileMenu] = useState(false);

  const handleSearch = (e: React.ChangeEvent<HTMLInputElement>) => {
    setSearchQuery(e.target.value);
    if (onSearchChange) {
      onSearchChange(e.target.value);
    }
  };

  return (
    <header className="sticky top-0 bg-[#1a2321]/80 backdrop-blur-3xl border-b border-[#1f6e65]/20 flex justify-between items-center w-full px-6 py-4 z-40">
      <div>
        <div className="flex items-center gap-3">
          <h2 className="font-serif-heading text-xl md:text-2xl text-[#8bd4c9] font-bold tracking-tight">
            Comparative Analysis Workbench
          </h2>
          <button
            onClick={onOpenExecutiveReport}
            className="hidden sm:flex items-center gap-1.5 px-2.5 py-1 text-xs font-medium bg-[#1f6e65]/30 hover:bg-[#1f6e65]/50 text-[#a3ede2] border border-[#1f6e65]/50 rounded-full transition-all"
            title="Generate AI Executive Report"
          >
            <Dna className="w-3.5 h-3.5" />
            <span>AI Report</span>
          </button>
        </div>
        <div className="flex items-center gap-2 text-[#9baba8] text-xs sm:text-sm mt-1">
          <span>Project: {currentExperiment.project}</span>
          <span className="w-1 h-1 rounded-full bg-[#8bd4c9]/50"></span>
          <span>Last synced {currentExperiment.lastSynced}</span>
        </div>
      </div>

      <div className="flex items-center gap-3 sm:gap-6">
        {/* Search Input */}
        <div className="relative hidden lg:block">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-[#bec9c6] w-4 h-4" />
          <input
            type="text"
            value={searchQuery}
            onChange={handleSearch}
            placeholder="Search sequence, gene, or variant..."
            className="bg-[#252b2a] border border-[#3f4947]/30 text-[#dee4e2] rounded-full py-1.5 pl-9 pr-4 w-64 text-sm focus:outline-none focus:border-[#8bd4c9] focus:ring-1 focus:ring-[#8bd4c9]/50 transition-all placeholder:text-[#bec9c6]/70 glow-effect"
          />
        </div>

        {/* Action Icons */}
        <div className="flex items-center gap-1">
          <button
            className="w-9 h-9 rounded-full hover:bg-[#303635] flex items-center justify-center text-[#bec9c6] hover:text-[#8bd4c9] transition-colors active:scale-95"
            title="Notifications"
          >
            <Bell className="w-4 h-4" />
          </button>
          <button
            className="w-9 h-9 rounded-full hover:bg-[#303635] flex items-center justify-center text-[#bec9c6] hover:text-[#8bd4c9] transition-colors active:scale-95"
            title="Workbench Settings"
          >
            <Settings className="w-4 h-4" />
          </button>
          <button
            className="w-9 h-9 rounded-full hover:bg-[#303635] flex items-center justify-center text-[#bec9c6] hover:text-[#8bd4c9] transition-colors active:scale-95"
            title="Help & Documentation"
          >
            <HelpCircle className="w-4 h-4" />
          </button>
        </div>

        <div className="w-px h-7 bg-[#3f4947]/40 mx-1 hidden sm:block"></div>

        {/* User Profile */}
        <div className="relative">
          <div
            onClick={() => setShowProfileMenu(!showProfileMenu)}
            className="flex items-center gap-2.5 cursor-pointer hover:bg-[#303635] p-1.5 rounded-xl transition-colors"
          >
            <div className="text-right hidden sm:block">
              <p className="text-sm font-medium text-[#dee4e2] leading-tight">Dr. A. Vance</p>
              <p className="text-[11px] text-[#9baba8]">Lead Bioengineer</p>
            </div>
            <img
              src="https://lh3.googleusercontent.com/aida-public/AB6AXuBGAOBxGo0puAPSEqOj_jp_szlEFUoZsl-ctbAMTRjmZO2m69nC87oq6LZlrLplaxnhzJpI9Bg-RaAxWzhYS5oCAwsXbKyqfej_0wFHYDQPZtbJuUy7NNHC5RuGg72LdJIUmf_Onrz2Jjawol_QPT0dY5V4iHYv2DzycLX6-gScEcFoNiRTiefoUf98lfR8-eALkvLGEJdkdu7PPIQ0Hf8WZVHcbZ7dLHOMGnodulhEc0CT8goxpL0L"
              alt="Dr. A. Vance"
              className="w-9 h-9 rounded-full object-cover border border-[#8bd4c9]/30"
            />
            <ChevronDown className="w-4 h-4 text-[#bec9c6]" />
          </div>

          {showProfileMenu && (
            <div className="absolute right-0 mt-2 w-56 bg-[#1a2321] border border-[#1f6e65]/30 rounded-xl shadow-2xl p-2 z-50 text-xs">
              <div className="px-3 py-2 border-b border-[#3f4947]/30">
                <p className="font-semibold text-[#dee4e2]">Dr. A. Vance</p>
                <p className="text-[#9baba8]">a.vance@biosynth.io</p>
                <p className="text-[10px] text-[#8bd4c9] mt-0.5">Role: Bioengineer Admin</p>
              </div>
              <button
                onClick={() => {
                  setShowProfileMenu(false);
                  onOpenExecutiveReport();
                }}
                className="w-full text-left px-3 py-2 text-[#dee4e2] hover:bg-[#303635] rounded-lg mt-1 transition-colors flex items-center justify-between"
              >
                <span>AI Executive Report</span>
                <span className="text-[10px] bg-[#1f6e65] text-[#a3ede2] px-1.5 py-0.5 rounded">Gemini</span>
              </button>
              <button
                onClick={() => setShowProfileMenu(false)}
                className="w-full text-left px-3 py-2 text-[#dee4e2] hover:bg-[#303635] rounded-lg transition-colors"
              >
                Account Settings
              </button>
            </div>
          )}
        </div>
      </div>
    </header>
  );
};
